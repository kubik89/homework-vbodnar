// 1
// let greating = "hello";
// let name1 = "owu";
// let domainCom = "com";
// let domainCountry = "ua";
// let digit1 = 1;
// let digit2 = 10;
// let digit3 = -999;
// let digit4 = 123;
// const Pi1 = 3.14;
// let digit5 = 2.7;
// let digit6 = 16;
// let digit7 = 7>6;
// let digit8 = 7<6;
// console.log(greating,name1,domainCom,domainCountry,digit1,digit2,digit3,digit4,Pi1,digit5,digit6,digit7,digit8);
// alert(greating);
// alert(name1);
// alert(domainCom);
// alert(domainCountry);
// alert(digit1);
// alert(digit2);
// alert(digit3);
// alert(digit4);
// alert(digit5);
// alert(digit6);
// alert(digit7);
// alert(digit8);
// document.write(greating,name1,domainCom,domainCountry,digit1,digit2,digit3,digit4,Pi1,digit5,digit6,digit7,digit8);

// 2
// greating = "hello new";
// name1 = "owu-new";
// domainCom = "net";
// domainCountry = "en";
// digit1 = 11;
// digit2 = 101;
// digit3 = -9991;
// digit4 = 1231;
// digit5 = 2.71;
// digit6 = 161;
// digit7 = 9>6;
// digit8 = 9<6;
// console.log(greating,name1,domainCom,domainCountry,digit1,digit2,digit3,digit4,Pi1,digit5,digit6,digit7,digit8);
// alert(greating);
// alert(name1);
// alert(domainCom);
// alert(domainCountry);
// alert(digit1);
// alert(digit2);
// alert(digit3);
// alert(digit4);
// alert(digit5);
// alert(digit6);
// alert(digit7);
// alert(digit8);
// document.write(greating,name1,domainCom,domainCountry,digit1,digit2,digit3,digit4,Pi1,digit5,digit6,digit7,digit8);
//
// // 3
// const companyName1 = "owu1";
// const companyName2 = "owu2";
// const companyName3 = "owu3";
// const companyYearth1 = "10";
// const companyYearth2 = "11";
// const companyYearth3 = "12";
// console.log(companyName1, companyName2, companyName3, companyYearth1, companyYearth2,companyYearth3);
// alert(companyName1);
// alert(companyName2);
// alert(companyName3);
// alert(companyYearth1);
// alert(companyYearth2);
// alert(companyYearth3);
// document.write(companyName1, companyName2, companyName3, companyYearth1, companyYearth2,companyYearth3);

// // 4
// let firstName = prompt("Enter your first name");
// let lastName = prompt("Enter your last name");
// let fatherName = prompt("Enter your fathers name");
// console.log(firstName, lastName, fatherName);
// alert(firstName);
// alert(lastName);
// alert(fatherName);
// document.write(firstName, lastName, fatherName);
//
// // 5
// let person = firstName+lastName+fatherName;

// 6


// 7
// let dig1 = +prompt("Enter first number");
// let dig2 = +prompt("Enter first number");
// let dig3 = +prompt("Enter first number");
// console.log(dig1, dig2, dig3);

// 8
// let d1 = parseInt(prompt("Enter the first number"));
// let d2 = parseInt(prompt("Enter the second number"));
// let d3 = parseInt(prompt("Enter the third number"));
// let d4 = parseInt(prompt("Enter the fourth number"));
// let result = d1 + d2 + d3 + d4;
// console.log(result);

// 9
// let d1f = parseFloat(prompt("Enter the first number"));
// let d2f = parseFloat(prompt("Enter the second number"));
// let d3f = parseFloat(prompt("Enter the third number"));
// let resultF = d1f + d2f + d3f;
// console.log(resultF);

// 10
// let d1f = parseFloat(prompt("Enter the first number"));
// let d2f = parseFloat(prompt("Enter the second number"));
// let d3f = parseFloat(prompt("Enter the third number"));
// let resultFMathR = Math.round(d1f) + Math.round(d2f) + Math.round(d3f);
// console.log(resultFMathR);

// 11
// let d1 = parseInt(prompt("Enter the first number"));
// let d2 = parseInt(prompt("Enter the second number"));
// let resultMathPow = Math.pow(d1, d2);
// console.log(resultMathPow);

// 12
// let a = 100;
// let b = "100";
// let c = true;
// let d = undefined;
// console.log(typeof a);
// console.log(typeof b);
// console.log(typeof c);
// console.log(typeof d);

// 13 - Поставьте соответствующий оператор в выражениях что бы получился соответсвующий результат.
// let a = 5 < 6; // true
// let b = 5 > 6; // false
// let c = 5 >= 6; // false
// let d = 5 === 6; // false
// let e = 10 === 10; // true
// let f = 10 >= 10; // true
// let g = 10 < 10; // false
// let h = 10 > 10; // false
// let i = 10 !== 10; // false
// let j = 123 === '123'; // false
// let k = 123 !== '123'; // true

// Class
// 1
// let a1 = "привет";
// console.log(typeof a1);
// let a2 = 123;
// console.log(typeof a2);
// let a3 = true;
// console.log(typeof a3);
// let a4 = "true";
// console.log(typeof a4);

// 2
// let a1 = 5 + 3;
// let a2 = 5 - 3;
// let a3 = 5 * 3;
// let a4 = 5 / 3;
// let a5 = 5 % 3;
// console.log(a1, a2, a3, a4, a5);

// 3
// let a6 = 5 % 3;
// let a7 = 3 % 5;
// let a8 = 5 + "3";
// let a9 = "5" - 3; // чому "5" тут як int ? бо результат 2
// let a10 = 75 + "кг";
// console.log(a6, a7, a8, a9, a10);

// 4
// let height = 23;
// let width = 10;
// let s = height * width;

// 5
// let heightC = 10;
// let dC = 4;
// let v = height * dC;

// 6    - чи можна задавати змінні з одинаковими значеннями в один рядок через кому? let n1, n2 = 3;
// let n = 3;
// let m = 4;
// let k = Math.pow(n, n)+Math.pow(m, m);
// console.log(k);
//
//     // 7
// let str = "Hello world";
// console.log(str);
// document.write(str);
// alert(str);

// 8
// let name = "Vova";
// let lname = "Bodnar";
// let age = 30;
// let hobby = "football \n" +
//     "volleyball \n";
// alert(name + lname + age);
// alert(hobby);

// 9
// let str1 = "Хто ";
// let str2 = "ти ";
// let str3 = "такий ";
// let concatenation = str1 + str2 + str3;
// document.write(concatenation);

// 10
// let str = "20";
// let a = 5;
// document.write(str / a + "<br/>");

// 12
// let str = prompt("Enter something", "ho-ho");
// console.log(str);
//

// 13
// let firstDig = +prompt("Введіть перше число");
// let secondDig = +prompt("Введіть друге число");
// let result = a + b;
// alert(result);

// 14

// let fName = prompt('Введіть імя');
// let sName = prompt('Введіть прізвище');
// let age = prompt('Введіть вік');
// document.write("Доброго вечера " + fName + ", " + "мои поздравления что вам " + age);


// Additional tasks

// 1 - 1. Три різних числа вводяться через prompt().
// За допомоги if else вивести іх в порядку зростання. (відсортувати по зростанню)

// let numbOne = +prompt("Enter the first number");
// let numbSecond = +prompt("Enter the second number", 21);
// let numbThree = +prompt("Enter the third number", 56);
//
// if ((numbOne < numbSecond && numbOne < numbThree) && (numbSecond < numbThree)) {
//     document.write(numbOne, numbSecond, numbThree);
// }
// if ((numbOne < numbSecond && numbOne < numbThree) && (numbThree < numbSecond)) {
//     document.write(numbOne, numbThree, numbSecond);
// }
// if ((numbSecond < numbOne && numbSecond < numbThree) && (numbOne < numbThree)) {
//     document.write(numbSecond, numbOne, numbThree);
// }
// if ((numbSecond < numbOne && numbSecond < numbThree) && (numbOne > numbThree)) {
//     document.write(numbSecond, numbThree, numbOne);
// }
// if ((numbThree < numbOne && numbThree < numbSecond) && (numbOne > numbSecond)) {
//     document.write(numbThree, numbSecond, numbOne);
// }
// if ((numbThree < numbOne && numbThree < numbSecond) && (numbSecond > numbOne)) {
//     document.write(numbThree, numbOne, numbSecond);
// }

    // 3

// let mess = prompt("Введіть колір, де r - червоний, y - жовтий, g - зелений");
// let isRoadClear = confirm("Машина є?");
// switch (mess) {
//     case "r":
//         if (!!isRoadClear) {
//             document.write("стой и жди")
//         }
//         else {
//         document.write("Стій");
//         }
//         break;
//     case "y":
//         if (!!isRoadClear) {
//             document.write("жди")
//         }
//         else {
//             document.write("всеравно жди");
//         }
//         break;
//     case "g":
//         if (!!isRoadClear) {
//             document.write("подожди пока нарушители проедут")
//         }
//         else {
//             document.write("иди");
//         }
//         break;
// }